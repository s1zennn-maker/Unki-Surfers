UNKI SURFERS — playable browser prototype

How to play:
1. Extract the ZIP archive.
2. Open index.html in a modern browser (Chrome recommended).
3. Tap ИГРАТЬ. On Android, use swipe gestures; on desktop, use arrow keys.

Included:
- 3-lane endless-runner prototype
- lane switching, jump, slide, obstacles and blue/white capsule pickups
- Unki character artwork cropped from the supplied reference
- six supplied MP3 files; randomized playlist shuffle with automatic next track

Important: This is a browser prototype, NOT an Android APK. An Android SDK/Gradle build environment is not available in this session, so I cannot honestly provide a compiled/installable APK here. The project can be wrapped in an Android WebView and built with Android Studio/Gradle.
